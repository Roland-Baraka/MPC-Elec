# Firmware ESP32-S3 — base d'intégration

Le fichier `.ino` est un squelette d'intégration. Il expose la structure du paquet et le BLE, mais les fonctions de lecture MLX90640/ADXL345 sont à connecter aux bibliothèques exactes choisies. Ne pas considérer les valeurs simulées comme mesures.
