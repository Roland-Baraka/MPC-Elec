/*
 SMART-THERMOÉLEC MP — firmware de départ
 Carte cible : ESP32-S3 DevKit
 Bus : I2C SDA=GPIO8, SCL=GPIO9 (à confirmer selon la carte choisie)
 Capteurs : MLX90640 (adresse typique 0x33), ADXL345 (souvent 0x53)
 BLE : service et caractéristique à figer avant liaison avec l'application.
 IMPORTANT : fonctions de capteurs non implémentées ici => aucune donnée réelle.
*/
#include <Arduino.h>
#include <Wire.h>
#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>

static const int I2C_SDA = 8;
static const int I2C_SCL = 9;
static const char* SERVICE_UUID = "6d4f0001-8a3b-4c7d-9e11-001122334455";
static const char* DATA_UUID    = "6d4f0002-8a3b-4c7d-9e11-001122334455";

BLECharacteristic* dataChar = nullptr;
uint32_t sequenceNo = 0;

void setup() {
  Serial.begin(115200);
  Wire.begin(I2C_SDA, I2C_SCL);
  Wire.setClock(400000);
  BLEDevice::init("SMART-THERMOELEC-MP");
  BLEServer* server = BLEDevice::createServer();
  BLEService* service = server->createService(SERVICE_UUID);
  dataChar = service->createCharacteristic(
    DATA_UUID,
    BLECharacteristic::PROPERTY_READ | BLECharacteristic::PROPERTY_NOTIFY
  );
  dataChar->setValue("DEMO;NO_SENSOR_DATA");
  service->start();
  BLEAdvertising* adv = BLEDevice::getAdvertising();
  adv->addServiceUUID(SERVICE_UUID);
  adv->start();
  Serial.println("SMART-THERMOELEC MP prêt — mode squelette, capteurs non lus.");
}

void loop() {
  // TODO 1 : lire 768 températures MLX90640 via bibliothèque Melexis.
  // TODO 2 : calculer Tmin, Tmax, Tmoy et ROI sans inventer de pixels.
  // TODO 3 : lire ADXL345 à fréquence fixe, horodater et calculer RMS/crête.
  // TODO 4 : valider qualité/erreurs de capteur avant notification.
  // Format provisoire à remplacer par un format binaire versionné :
  // v1,seq,timestamp_ms,tmax_c,tmean_c,ax,ay,az,status
  String demo = "v1," + String(sequenceNo++) + ",0,NA,NA,NA,NA,NA,DEMO";
  dataChar->setValue(demo.c_str());
  dataChar->notify();
  delay(1000);
}
