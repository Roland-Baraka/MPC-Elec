# Obtenir l'APK sans ordinateur (depuis le Tecno Camon 19)

Ce projet contient un workflow GitHub Actions qui compile l'APK dans le cloud. Aucun Android Studio n'est nécessaire sur le téléphone.

## Étapes
1. Connecte-toi ou crée gratuitement un compte sur GitHub.
2. Dans Chrome sur le téléphone, ouvre GitHub et crée un dépôt public nommé `SMART-THERMOELEC-MP`.
3. Téléverse le contenu de cette archive dans le dépôt en conservant les dossiers `android_app`, `firmware_esp32`, `docs` et `.github` à la racine. Le fichier `.github/workflows/build-apk.yml` est indispensable.
4. Ouvre l'onglet **Actions** du dépôt. Si GitHub demande d'autoriser les workflows, accepte.
5. Sélectionne **Construire APK SMART-THERMOELEC MP**, puis **Run workflow**.
6. Attends que l'exécution soit terminée avec une coche verte. Si elle échoue, ouvre l'exécution et consulte les journaux : ne considère pas l'APK comme produit.
7. Dans le résumé de l'exécution réussie, télécharge l'artefact `SMART-THERMOELEC-MP-APK-debug`.
8. Décompresse l'archive téléchargée, puis installe `app-debug.apk` sur Android. Autorise l'installation depuis Chrome/Fichiers uniquement si Android le demande.

## Limites de cette APK
Il s'agit d'une APK de démonstration native. Elle permet d'essayer l'interface et le diagnostic avec des valeurs saisies manuellement. Elle ne lit pas encore le MLX90640 ou l'ADXL345, ne communique pas encore avec l'ESP32 et ne doit pas servir à protéger une machine réelle.

L'APK debug n'est pas une version de publication signée pour Play Store. Garder l'installation limitée à son propre appareil de test.
