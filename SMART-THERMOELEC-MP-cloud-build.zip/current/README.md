# SMART-THERMOÉLEC MP — prototype Android v0.3

Application Android native Kotlin / Jetpack Compose. Le projet est configuré pour une compilation cloud via GitHub Actions afin de pouvoir produire un APK depuis un téléphone, sans installer Android Studio.

Voir `DEMARRER-DEPUIS-TELEPHONE.md` pour la procédure.

**État honnête :** l'application est un prototype logiciel de démonstration. Les mesures sont saisies manuellement. Le BLE, les capteurs MLX90640/ADXL345, l'IA entraînée, les alertes de terrain et les essais industriels restent à réaliser. L'APK n'est pas encore compilé; GitHub Actions doit terminer avec succès avant de pouvoir le télécharger.
