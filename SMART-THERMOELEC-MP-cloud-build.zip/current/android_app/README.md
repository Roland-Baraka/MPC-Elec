# SMART-THERMOÉLEC MP — prototype Android v0.3

Propriétaire du projet : BARAKA MUPIMBI Roland  
Application : `com.smartthermoelec.mp`  
Min Android : 8.0 (API 26)

## Ce qui fonctionne dans cette version
- Interface Android native Kotlin / Jetpack Compose.
- Saisie manuelle d'une température, température ambiante, seuils et confiance.
- Activation/désactivation de l'état de fonctionnement.
- Moteur déterministe de diagnostic : données insuffisantes, normal, vigilance, avertissement, critique.
- Refus de conclure si les données ou seuils sont invalides/incomplets.
- Recommandations et avertissement de sécurité.

## Ce qui n'est PAS encore réalisé
- Aucune mesure automatique : les chiffres sont saisis manuellement.
- Pas encore de liaison Bluetooth BLE fonctionnelle.
- Firmware ESP32 encore squelette : MLX90640 et ADXL345 non lus.
- Pas encore de caméra thermique, traitement audio, IA entraînée, historique persistant ni notifications.
- Pas encore d'APK compilé ou testé sur TECNO Camon 19.

## Compiler
1. Ouvrir ce dossier `android_app` dans Android Studio récent.
2. Laisser Gradle télécharger les dépendances (connexion nécessaire au premier build).
3. Connecter le téléphone en débogage USB ou choisir un émulateur.
4. Choisir Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Tester le fichier `app/build/outputs/apk/debug/app-debug.apk`.

## Sécurité et limites
Les seuils doivent être renseignés à partir de la documentation du constructeur, des normes applicables et d'une validation métrologique. Les seuils préremplis sont des valeurs de démonstration modifiables, pas des limites universelles. Cette application ne constitue pas un dispositif de protection électrique et ne doit pas piloter l'arrêt d'une machine.
