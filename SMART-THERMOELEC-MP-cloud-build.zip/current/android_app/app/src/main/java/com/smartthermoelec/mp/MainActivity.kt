package com.smartthermoelec.mp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.Image
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SmartThermoelecApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SmartThermoelecApp() {
    var equipment by remember { mutableStateOf("Moteur triphasé 3 kW") }
    var running by remember { mutableStateOf(true) }
    var temperature by remember { mutableStateOf("48.6") }
    var ambient by remember { mutableStateOf("27.0") }
    var warning by remember { mutableStateOf("70") }
    var critical by remember { mutableStateOf("90") }
    var confidence by remember { mutableStateOf("0.95") }
    var hasAnalyzed by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<DiagnosticResult?>(null) }

    MaterialTheme(colorScheme = lightColorScheme(primary = Color(0xFF075985))) {
        Scaffold(topBar = { TopAppBar(title = { Text("SMART-THERMOÉLEC MP") }) }) { padding ->
            Column(
                Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Image(painter = painterResource(R.drawable.smart_thermo_logo), contentDescription = "Logo SMART-THERMOÉLEC MP", modifier = Modifier.fillMaxWidth().height(150.dp), contentScale = ContentScale.Fit)
                Text("SURVEILLANCE THERMIQUE", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("Prototype logiciel — mesures saisies manuellement, aucun capteur réel connecté.", color = Color(0xFF9B2226), fontWeight = FontWeight.SemiBold)
                OutlinedTextField(equipment, { equipment = it }, label = { Text("Équipement surveillé") }, modifier = Modifier.fillMaxWidth())
                Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Text("Équipement en fonctionnement", modifier = Modifier.weight(1f))
                    Switch(checked = running, onCheckedChange = { running = it })
                }
                NumberField("Température mesurée (°C)", temperature) { temperature = it }
                NumberField("Température ambiante (°C)", ambient) { ambient = it }
                NumberField("Seuil de vigilance (°C)", warning) { warning = it }
                NumberField("Seuil critique (°C)", critical) { critical = it }
                NumberField("Confiance de la mesure (0 à 1)", confidence) { confidence = it }
                Button(onClick = {
                    val t = temperature.toDoubleOrNull()
                    val a = ambient.toDoubleOrNull()
                    val w = warning.toDoubleOrNull()
                    val c = critical.toDoubleOrNull()
                    val q = confidence.toDoubleOrNull()
                    result = if (t != null && a != null && w != null && c != null && q != null) {
                        DiagnosticEngine.analyze(
                            EquipmentProfile(equipment, w, c, minimumConfidence = 0.80),
                            DiagnosticInput(running, t, a, source = MeasurementSource.MANUAL, confidence = q)
                        )
                    } else null
                    hasAnalyzed = true
                }, modifier = Modifier.fillMaxWidth()) { Text("ANALYSER") }
                if (hasAnalyzed) {
                    val r = result
                    if (r == null) {
                        Text("Valeur invalide : vérifie les champs numériques.", color = Color.Red)
                    } else {
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("RÉSULTAT : ${r.level}", fontWeight = FontWeight.Bold, color = when (r.level) {
                                    RiskLevel.CRITICAL -> Color(0xFFB00020)
                                    RiskLevel.WARNING -> Color(0xFFB45309)
                                    RiskLevel.WATCH -> Color(0xFF9A6700)
                                    RiskLevel.NORMAL -> Color(0xFF15803D)
                                    else -> Color.DarkGray
                                })
                                Text(r.title, style = MaterialTheme.typography.titleMedium)
                                Text(r.explanation)
                                Text("Actions recommandées", fontWeight = FontWeight.Bold)
                                r.recommendations.forEach { Text("• $it") }
                            }
                        }
                    }
                }
                HorizontalDivider()
                Text("SÉCURITÉ : cette application expérimentale ne remplace ni les protections électriques, ni un instrument étalonné, ni l'avis d'un technicien qualifié. Ne jamais approcher le téléphone ou un montage non isolé de conducteurs sous tension.", style = MaterialTheme.typography.bodySmall)
                Text("Version 0.3 — diagnostic manuel local. BLE, MLX90640, accéléromètre et historique restent à intégrer.", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun NumberField(label: String, value: String, onValueChange: (String) -> Unit) {
    OutlinedTextField(value, onValueChange, label = { Text(label) }, modifier = Modifier.fillMaxWidth(), singleLine = true)
}
