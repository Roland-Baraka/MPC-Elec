package com.smartthermoelec.mp

/**
 * SMART-THERMOÉLEC MP — moteur de décision déterministe v0.2 (socle expérimental).
 * IMPORTANT : aucune limite thermique n'est codée en dur. Les seuils doivent provenir
 * de la plaque signalétique, du fabricant, des normes applicables et d'une validation
 * par instrument étalonné. Ce moteur ne remplace pas une protection électrique.
 */

enum class RiskLevel { INSUFFICIENT_DATA, NORMAL, WATCH, WARNING, CRITICAL }
enum class MeasurementSource { CONTACT_PROBE, CALIBRATED_THERMAL_SENSOR, PHONE_CAMERA, AUDIO_ONLY, MANUAL }

data class EquipmentProfile(
    val name: String,
    val warningTemperatureC: Double?,
    val criticalTemperatureC: Double?,
    val maximumRiseAboveAmbientC: Double? = null,
    val minimumConfidence: Double = 0.80
)

data class DiagnosticInput(
    val equipmentRunning: Boolean,
    val measuredTemperatureC: Double? = null,
    val ambientTemperatureC: Double? = null,
    val temperatureTrendCPerMinute: Double? = null,
    val acousticAnomalyScore: Double? = null, // 0.0 à 1.0, modèle acoustique validé requis
    val source: MeasurementSource,
    val confidence: Double
)

data class DiagnosticResult(
    val level: RiskLevel,
    val title: String,
    val explanation: String,
    val recommendations: List<String>,
    val requiresHumanVerification: Boolean = true
)

object DiagnosticEngine {
    fun analyze(profile: EquipmentProfile, input: DiagnosticInput): DiagnosticResult {
        if (!input.equipmentRunning) return result(
            RiskLevel.INSUFFICIENT_DATA, "Équipement à l'arrêt",
            "L'analyse de fonctionnement est suspendue : les signatures doivent être relevées pendant un fonctionnement contrôlé.",
            listOf("Confirmer l'état de fonctionnement avant toute acquisition.")
        )
        if (input.confidence !in 0.0..1.0 || input.confidence < profile.minimumConfidence) return result(
            RiskLevel.INSUFFICIENT_DATA, "Données insuffisantes",
            "La confiance de mesure est trop faible pour produire une évaluation.",
            listOf("Répéter la mesure avec un capteur adapté et vérifier son étalonnage.")
        )
        if (input.source == MeasurementSource.AUDIO_ONLY || input.source == MeasurementSource.PHONE_CAMERA) {
            if (input.measuredTemperatureC == null) return result(
                RiskLevel.INSUFFICIENT_DATA, "Température non mesurée",
                "Cette source ne fournit pas, à elle seule, une température de contact fiable.",
                listOf("Utiliser une sonde ou un capteur thermique compatible et étalonné.", "L'analyse audio/visuelle peut uniquement compléter l'inspection.")
            )
        }
        val temp = input.measuredTemperatureC
        if (temp == null || !temp.isFinite() || temp < -50.0 || temp > 500.0) return result(
            RiskLevel.INSUFFICIENT_DATA, "Mesure thermique invalide",
            "Aucune température exploitable n'a été fournie.",
            listOf("Contrôler le capteur, son unité et son étalonnage.")
        )
        val warning = profile.warningTemperatureC
        val critical = profile.criticalTemperatureC
        if (warning == null || critical == null || !warning.isFinite() || !critical.isFinite() || critical <= warning) return result(
            RiskLevel.INSUFFICIENT_DATA, "Profil thermique incomplet",
            "Les seuils validés pour cet équipement ne sont pas configurés.",
            listOf("Renseigner les limites du fabricant et les exigences normatives applicables avant le diagnostic.")
        )
        if (temp >= critical) return result(
            RiskLevel.CRITICAL, "Seuil critique atteint",
            "La température mesurée atteint ou dépasse la limite critique configurée.",
            listOf("Ne pas toucher l'équipement.", "Appliquer la procédure de sécurité du site et faire vérifier par une personne qualifiée.")
        )
        if (temp >= warning) return result(
            RiskLevel.WARNING, "Température élevée",
            "La température mesurée atteint le seuil d'avertissement configuré.",
            listOf("Faire contrôler l'équipement par un technicien qualifié.", "Comparer avec les mesures précédentes et les conditions de charge.")
        )
        val rise = if (input.ambientTemperatureC != null) temp - input.ambientTemperatureC else null
        if (profile.maximumRiseAboveAmbientC != null && rise != null && rise >= profile.maximumRiseAboveAmbientC) return result(
            RiskLevel.WATCH, "Échauffement relatif à surveiller",
            "L'écart entre la température mesurée et l'ambiante dépasse le seuil configuré.",
            listOf("Répéter les mesures dans des conditions de charge comparables.", "Vérifier ventilation, connexions et charge selon les procédures autorisées.")
        )
        if ((input.temperatureTrendCPerMinute ?: 0.0) > 0.5 || (input.acousticAnomalyScore ?: 0.0) >= 0.75) return result(
            RiskLevel.WATCH, "Anomalie à surveiller",
            "Une hausse rapide de température ou une anomalie acoustique a été signalée ; elle ne constitue pas seule une preuve de surchauffe.",
            listOf("Confirmer avec une mesure thermique étalonnée.", "Inspecter l'équipement selon les règles de sécurité du site.")
        )
        return result(
            RiskLevel.NORMAL, "Aucun dépassement des seuils configurés",
            "La mesure fournie reste sous les seuils configurés. Cela ne certifie pas que l'équipement est sans danger.",
            listOf("Continuer la surveillance et conserver les mesures pour établir une tendance.")
        )
    }

    private fun result(level: RiskLevel, title: String, explanation: String, recommendations: List<String>) =
        DiagnosticResult(level, title, explanation, recommendations)
}
