# Protocole BLE proposé (à figer)
Service UUID : 6d4f0001-8a3b-4c7d-9e11-001122334455
Characteristic UUID : 6d4f0002-8a3b-4c7d-9e11-001122334455
Propriétés : READ + NOTIFY.

Paquet logique recommandé :
- version (uint8)
- sequence (uint32)
- timestamp_ms (uint64)
- Tmax_centiC (int16)
- Tmean_centiC (int16)
- Tmin_centiC (int16)
- accel_rms_mg (uint16)
- accel_peak_mg (uint16)
- status_flags (uint16)
- crc16 (uint16)

Les unités, endianness, échelle, gestion du dépassement et compatibilité firmware doivent être documentées avant intégration. Le firmware fourni transmet volontairement une chaîne DEMO et n'effectue pas de mesure réelle.
