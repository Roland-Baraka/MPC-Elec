package com.smartthermoelec.mp.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class Measurement(
    val timestamp: Long,
    val maxTempC: Float,
    val meanTempC: Float,
    val minTempC: Float,
    val accelRmsMg: Int,
    val accelPeakMg: Int,
    val flags: Int,
    val source: String = "BLE"
)

/** Stockage local SQLite; les lignes restent disponibles après fermeture de l'application. */
class MeasurementStore(context: Context) :
    SQLiteOpenHelper(context, "smart_thermoelec.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE measurements (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp INTEGER NOT NULL,
                max_temp REAL NOT NULL,
                mean_temp REAL NOT NULL,
                min_temp REAL NOT NULL,
                accel_rms INTEGER NOT NULL,
                accel_peak INTEGER NOT NULL,
                flags INTEGER NOT NULL,
                source TEXT NOT NULL
            )
        """.trimIndent())
        db.execSQL("CREATE INDEX idx_measurements_timestamp ON measurements(timestamp)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Toute migration future doit préserver les données; ne pas supprimer la table.
    }

    fun insert(m: Measurement): Long {
        val values = ContentValues().apply {
            put("timestamp", m.timestamp)
            put("max_temp", m.maxTempC)
            put("mean_temp", m.meanTempC)
            put("min_temp", m.minTempC)
            put("accel_rms", m.accelRmsMg)
            put("accel_peak", m.accelPeakMg)
            put("flags", m.flags)
            put("source", m.source)
        }
        return writableDatabase.insertOrThrow("measurements", null, values)
    }

    fun latest(limit: Int = 100): List<Measurement> {
        val rows = mutableListOf<Measurement>()
        readableDatabase.query(
            "measurements",
            arrayOf("timestamp", "max_temp", "mean_temp", "min_temp", "accel_rms", "accel_peak", "flags", "source"),
            null, null, null, null, "timestamp DESC", limit.coerceIn(1, 1000).toString()
        ).use { c ->
            while (c.moveToNext()) {
                rows += Measurement(
                    timestamp = c.getLong(0),
                    maxTempC = c.getFloat(1),
                    meanTempC = c.getFloat(2),
                    minTempC = c.getFloat(3),
                    accelRmsMg = c.getInt(4),
                    accelPeakMg = c.getInt(5),
                    flags = c.getInt(6),
                    source = c.getString(7)
                )
            }
        }
        return rows
    }
}
