package com.smartthermoelec.mp.ai

import kotlin.math.max

/**
 * Moteur de classification explicable (baseline avant IA entraînée).
 * Les seuils viennent d'un profil validé pour UN type/modèle/charge/vitesse précis.
 * Aucune valeur universelle n'est intégrée au code.
 */
enum class ConditionBand { NORMAL, TENDANCE, ECHAUFFEMENT, DONNEES_INSUFFISANTES }
enum class OverallState { NORMAL, SURVEILLANCE, ALERTE, DONNEES_INSUFFISANTES }

data class RangeBand(val min: Double, val max: Double) {
    init { require(min < max) }
    fun contains(value: Double) = value >= min && value < max
}

data class EquipmentReferenceProfile(
    val profileId: String,
    val equipmentType: String,
    val ambientReferenceC: Double,
    val normalDeltaTempC: RangeBand,
    val tendencyDeltaTempC: RangeBand,
    val heatingDeltaTempC: RangeBand,
    val normalSoundDbSpl: RangeBand?,
    val tendencySoundDbSpl: RangeBand?,
    val heatingSoundDbSpl: RangeBand?,
    val normalAccelerationMg: RangeBand? = null,
    val tendencyAccelerationMg: RangeBand? = null,
    val heatingAccelerationMg: RangeBand? = null,
    val validated: Boolean = false
) {
    init {
        require(profileId.isNotBlank() && equipmentType.isNotBlank())
        require(normalDeltaTempC.max <= tendencyDeltaTempC.max)
        require(tendencyDeltaTempC.max <= heatingDeltaTempC.max)
    }
}

data class ConditionSample(
    val timestampMs: Long,
    val surfaceMaxC: Double?,
    val ambientC: Double?,
    /** Niveau acoustique pondéré A, dB SPL, seulement si microphone étalonné. */
    val soundLevelDbSpl: Double? = null,
    /** Accélération RMS dynamique en mg, idéalement issue d'un capteur fixé à la machine. */
    val accelerationRmsMg: Double? = null,
    val machineRunning: Boolean,
    val loadPercent: Double? = null,
    val rpm: Double? = null
)

data class ChannelAssessment(val band: ConditionBand, val value: Double?, val explanation: String)
data class ConditionAssessment(
    val state: OverallState,
    val thermal: ChannelAssessment,
    val acoustic: ChannelAssessment,
    val acceleration: ChannelAssessment,
    val temperatureRiseC: Double?,
    val trendCPerMinute: Double?,
    val explanation: String
)

class ConditionAssessmentEngine {
    private var previous: ConditionSample? = null

    fun evaluate(sample: ConditionSample, profile: EquipmentReferenceProfile): ConditionAssessment {
        if (!sample.machineRunning) {
            previous = sample
            val stopped = ChannelAssessment(ConditionBand.DONNEES_INSUFFISANTES, null, "Machine à l'arrêt : classification en marche suspendue.")
            return ConditionAssessment(OverallState.DONNEES_INSUFFISANTES, stopped, stopped, stopped, null, null,
                "L'équipement est déclaré à l'arrêt.")
        }
        val surface = sample.surfaceMaxC
        val ambient = sample.ambientC
        val rise = if (surface != null && ambient != null) surface - ambient else null
        val thermal = classify(rise, profile.normalDeltaTempC, profile.tendencyDeltaTempC,
            profile.heatingDeltaTempC, "Écart surface-ambiance")
        val acoustic = classifyOptional(sample.soundLevelDbSpl, profile.normalSoundDbSpl,
            profile.tendencySoundDbSpl, profile.heatingSoundDbSpl, "Niveau acoustique dB SPL")
        val acceleration = classifyOptional(sample.accelerationRmsMg, profile.normalAccelerationMg,
            profile.tendencyAccelerationMg, profile.heatingAccelerationMg, "Accélération RMS")

        val trend = previous?.let { p ->
            val oldRise = if (p.surfaceMaxC != null && p.ambientC != null) p.surfaceMaxC - p.ambientC else null
            val dtMin = (sample.timestampMs - p.timestampMs) / 60000.0
            if (rise != null && oldRise != null && dtMin > 0.0) (rise - oldRise) / dtMin else null
        }
        previous = sample

        val bands = listOf(thermal.band, acoustic.band, acceleration.band)
        val valid = bands.filter { it != ConditionBand.DONNEES_INSUFFISANTES }
        val state = when {
            !profile.validated || thermal.band == ConditionBand.DONNEES_INSUFFISANTES -> OverallState.DONNEES_INSUFFISANTES
            valid.any { it == ConditionBand.ECHAUFFEMENT } -> OverallState.ALERTE
            valid.count { it == ConditionBand.TENDANCE } >= 2 || thermal.band == ConditionBand.TENDANCE -> OverallState.SURVEILLANCE
            else -> OverallState.NORMAL
        }
        val message = when (state) {
            OverallState.NORMAL -> "Les canaux disponibles restent dans les plages normales du profil ${profile.profileId}."
            OverallState.SURVEILLANCE -> "Une dérive est détectée. Vérifier charge, ventilation, roulements et connexions."
            OverallState.ALERTE -> "Au moins un canal atteint la plage échauffement/anomalie. Faire vérifier par un technicien qualifié."
            OverallState.DONNEES_INSUFFISANTES -> "Profil non validé ou mesure thermique/ambiante manquante : résultat non concluant."
        }
        return ConditionAssessment(state, thermal, acoustic, acceleration, rise, trend, message)
    }

    private fun classify(value: Double?, normal: RangeBand, tendency: RangeBand,
                         heating: RangeBand, label: String): ChannelAssessment {
        if (value == null || !value.isFinite()) return ChannelAssessment(ConditionBand.DONNEES_INSUFFISANTES, value, "$label indisponible.")
        val band = when {
            normal.contains(value) -> ConditionBand.NORMAL
            tendency.contains(value) -> ConditionBand.TENDANCE
            heating.contains(value) || value >= heating.max -> ConditionBand.ECHAUFFEMENT
            else -> ConditionBand.DONNEES_INSUFFISANTES
        }
        return ChannelAssessment(band, value, "$label = %.2f ; classe %s.".format(value, band))
    }

    private fun classifyOptional(value: Double?, normal: RangeBand?, tendency: RangeBand?,
                                 heating: RangeBand?, label: String): ChannelAssessment {
        if (value == null || normal == null || tendency == null || heating == null)
            return ChannelAssessment(ConditionBand.DONNEES_INSUFFISANTES, value, "$label non étalonné ou non configuré.")
        return classify(value, normal, tendency, heating, label)
    }
}
