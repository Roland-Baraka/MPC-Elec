package com.smartthermoelec.mp.ai

/**
 * Détecteur statistique de référence, PAS une IA entraînée.
 * Il signale un écart à une ligne de base fournie après une période de fonctionnement sain.
 * Il ne prédit pas une panne et ne remplace aucune protection.
 */
data class Baseline(val mean: Double, val standardDeviation: Double, val sampleCount: Int)

enum class AnomalyLevel { INSUFFICIENT_DATA, NORMAL, WATCH, ANOMALY }

object AnomalyBaseline {
    fun evaluate(value: Double, baseline: Baseline): AnomalyLevel {
        if (!value.isFinite() || baseline.sampleCount < 30 ||
            !baseline.mean.isFinite() || !baseline.standardDeviation.isFinite() ||
            baseline.standardDeviation <= 0.0
        ) return AnomalyLevel.INSUFFICIENT_DATA

        val z = kotlin.math.abs(value - baseline.mean) / baseline.standardDeviation
        return when {
            z >= 4.0 -> AnomalyLevel.ANOMALY
            z >= 2.5 -> AnomalyLevel.WATCH
            else -> AnomalyLevel.NORMAL
        }
    }
}
