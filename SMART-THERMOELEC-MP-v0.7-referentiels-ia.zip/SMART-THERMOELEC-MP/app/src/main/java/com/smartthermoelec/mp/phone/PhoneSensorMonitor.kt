package com.smartthermoelec.mp.phone

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import kotlin.math.sqrt

/**
 * Capteurs du téléphone : accéléromètre + microphone.
 * Les valeurs sont des indicateurs de tendance, pas des mesures vibratoires/thermiques certifiées.
 * Le microphone enregistre uniquement pendant startMicrophone() et doit être autorisé par l'utilisateur.
 */
class PhoneSensorMonitor(context: Context, private val onReading: (PhoneReading) -> Unit) :
    SensorEventListener {

    private val manager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val accelerometer = manager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    private var latestX = 0f
    private var latestY = 0f
    private var latestZ = 0f
    private var audioRecord: AudioRecord? = null
    @Volatile private var audioRunning = false

    data class PhoneReading(
        val accelerationMagnitudeMs2: Float,
        val vibrationVariationMs2: Float,
        val microphoneRms: Float? = null
    )

    fun hasAccelerometer(): Boolean = accelerometer != null

    fun startAccelerometer() {
        accelerometer?.let {
            manager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
        }
    }

    fun stopAccelerometer() {
        manager.unregisterListener(this)
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type != Sensor.TYPE_ACCELEROMETER) return
        latestX = event.values[0]
        latestY = event.values[1]
        latestZ = event.values[2]
        val magnitude = sqrt(latestX * latestX + latestY * latestY + latestZ * latestZ)
        val dynamic = kotlin.math.abs(magnitude - SensorManager.GRAVITY_EARTH)
        onReading(PhoneReading(magnitude, dynamic))
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    /**
     * Requires android.permission.RECORD_AUDIO granted at runtime.
     * Raw audio is not saved or transmitted; only RMS amplitude is reported.
     */
    fun startMicrophone() {
        if (audioRunning) return
        val sampleRate = 16000
        val minBytes = AudioRecord.getMinBufferSize(
            sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        if (minBytes <= 0) return
        val recorder = if (Build.VERSION.SDK_INT >= 31) {
            AudioRecord.Builder()
                .setAudioSource(MediaRecorder.AudioSource.MIC)
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .build()
                )
                .setBufferSizeInBytes(minBytes * 2)
                .build()
        } else {
            @Suppress("DEPRECATION")
            AudioRecord(
                MediaRecorder.AudioSource.MIC, sampleRate,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, minBytes * 2
            )
        }
        if (recorder.state != AudioRecord.STATE_INITIALIZED) {
            recorder.release()
            return
        }
        audioRecord = recorder
        audioRunning = true
        recorder.startRecording()
        Thread {
            val buffer = ShortArray(1024)
            while (audioRunning) {
                val count = recorder.read(buffer, 0, buffer.size)
                if (count > 0) {
                    var sum = 0.0
                    for (i in 0 until count) {
                        val v = buffer[i].toDouble()
                        sum += v * v
                    }
                    val rms = sqrt(sum / count).toFloat()
                    onReading(PhoneReading(0f, 0f, rms))
                }
            }
        }.apply { name = "SmartThermoMic"; isDaemon = true; start() }
    }

    fun stopMicrophone() {
        audioRunning = false
        runCatching { audioRecord?.stop() }
        audioRecord?.release()
        audioRecord = null
    }

    fun release() {
        stopAccelerometer()
        stopMicrophone()
    }
}
