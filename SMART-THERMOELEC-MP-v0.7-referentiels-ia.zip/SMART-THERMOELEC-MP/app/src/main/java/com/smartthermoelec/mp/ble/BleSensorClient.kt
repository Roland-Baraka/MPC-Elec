package com.smartthermoelec.mp.ble

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanFilter
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import android.bluetooth.BluetoothManager
import android.os.ParcelUuid

/**
 * Client BLE pour le service SMART-THERMOÉLEC.
 * L'écran appelant doit demander BLUETOOTH_SCAN/CONNECT à l'exécution avant startScan().
 */
class BleSensorClient(
    context: Context,
    private val onStatus: (String) -> Unit,
    private val onPacket: (SensorPacket) -> Unit
) {
    private val appContext = context.applicationContext
    private val manager = appContext.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
    private val scanner get() = manager.adapter?.bluetoothLeScanner
    private var gatt: BluetoothGatt? = null

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val device = result.device
            stopScan()
            onStatus("Capteur trouvé : ${device.name ?: "SMART-THERMOÉLEC"} — connexion…")
            connect(device)
        }
        override fun onScanFailed(errorCode: Int) {
            onStatus("Échec du scan BLE (code $errorCode)")
        }
    }

    @SuppressLint("MissingPermission")
    fun startScan() {
        val bleScanner = scanner
        if (bleScanner == null) {
            onStatus("Bluetooth LE indisponible ou désactivé")
            return
        }
        val filter = ScanFilter.Builder().setServiceUuid(ParcelUuid(BleProtocol.SERVICE_UUID)).build()
        val settings = ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build()
        onStatus("Recherche du capteur ESP32…")
        bleScanner.startScan(listOf(filter), settings, scanCallback)
    }

    @SuppressLint("MissingPermission")
    fun stopScan() {
        runCatching { scanner?.stopScan(scanCallback) }
    }

    @SuppressLint("MissingPermission")
    private fun connect(device: BluetoothDevice) {
        gatt?.close()
        gatt = device.connectGatt(appContext, false, callback)
    }

    private val callback = object : BluetoothGattCallback() {
        @SuppressLint("MissingPermission")
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            if (status != BluetoothGatt.GATT_SUCCESS) {
                onStatus("Erreur de connexion BLE : $status")
                g.close()
                return
            }
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                onStatus("ESP32 connecté — découverte des services…")
                g.discoverServices()
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                onStatus("ESP32 déconnecté")
                g.close()
                if (gatt === g) gatt = null
            }
        }

        @SuppressLint("MissingPermission")
        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            val characteristic = g.getService(BleProtocol.SERVICE_UUID)
                ?.getCharacteristic(BleProtocol.CHARACTERISTIC_UUID)
            if (status != BluetoothGatt.GATT_SUCCESS || characteristic == null) {
                onStatus("Service/capteur incompatible : UUID introuvable")
                return
            }
            g.setCharacteristicNotification(characteristic, true)
            val descriptor = characteristic.getDescriptor(BleProtocol.CCCD_UUID)
            if (descriptor == null) {
                onStatus("Descripteur de notification absent")
                return
            }
            descriptor.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
            g.writeDescriptor(descriptor)
            onStatus("Notifications capteur activées")
        }

        override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
            if (characteristic.uuid != BleProtocol.CHARACTERISTIC_UUID) return
            val packet = characteristic.value?.let(BleProtocol::decode)
            if (packet == null) onStatus("Paquet capteur invalide (CRC/format)")
            else onPacket(packet)
        }
    }

    @SuppressLint("MissingPermission")
    fun close() {
        stopScan()
        gatt?.disconnect()
        gatt?.close()
        gatt = null
    }
}
