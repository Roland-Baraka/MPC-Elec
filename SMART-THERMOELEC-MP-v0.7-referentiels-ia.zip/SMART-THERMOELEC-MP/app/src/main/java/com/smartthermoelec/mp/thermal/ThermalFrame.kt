package com.smartthermoelec.mp.thermal

/**
 * Image thermique 32 x 24 transmise par le module optionnel ESP32 + MLX90640.
 * Les valeurs représentent des températures apparentes en centi-degrés Celsius.
 */
data class ThermalFrame(
    val sequence: Long,
    val timestampMs: Long,
    val temperaturesC: FloatArray
) {
    init { require(temperaturesC.size == PIXELS) }
    val minC: Float get() = temperaturesC.minOrNull() ?: Float.NaN
    val maxC: Float get() = temperaturesC.maxOrNull() ?: Float.NaN
    val meanC: Float get() = temperaturesC.average().toFloat()

    companion object {
        const val WIDTH = 32
        const val HEIGHT = 24
        const val PIXELS = WIDTH * HEIGHT
    }
}

/**
 * Décodeur de trames thermiques fragmentées.
 * Format de chaque fragment (little-endian):
 * magic 2 octets 'T','F'; version u8; frameId u16; fragmentIndex u8;
 * fragmentCount u8; pixelStart u16; pixelCount u8; pixelCount valeurs int16 centi°C;
 * CRC16-CCITT sur tous les octets sauf les deux derniers.
 *
 * Le firmware doit envoyer les fragments dans l'ordre; la trame n'est publiée
 * qu'après réception complète de ses 768 pixels. Le protocole doit être validé
 * avec le firmware correspondant avant usage.
 */
object ThermalFrameProtocol {
    private data class Assembly(
        val frameId: Int,
        val count: Int,
        val values: FloatArray = FloatArray(ThermalFrame.PIXELS) { Float.NaN },
        val received: BooleanArray = BooleanArray(ThermalFrame.PIXELS)
    )
    private var current: Assembly? = null

    @Synchronized
    fun accept(fragment: ByteArray, timestampMs: Long = System.currentTimeMillis()): ThermalFrame? {
        if (fragment.size < 13 || fragment[0] != 'T'.code.toByte() || fragment[1] != 'F'.code.toByte()) return null
        val expected = crc16(fragment, 0, fragment.size - 2)
        val receivedCrc = (fragment[fragment.size - 2].toInt() and 255) or
            ((fragment[fragment.size - 1].toInt() and 255) shl 8)
        if (expected != receivedCrc) return null
        fun u8(i: Int) = fragment[i].toInt() and 255
        fun u16(i: Int) = u8(i) or (u8(i + 1) shl 8)
        if (u8(2) != 1) return null
        val frameId = u16(3)
        val fragmentIndex = u8(5)
        val fragmentCount = u8(6)
        val pixelStart = u16(7)
        val pixelCount = u8(9)
        if (fragmentCount == 0 || fragmentIndex >= fragmentCount ||
            pixelCount == 0 || pixelStart + pixelCount > ThermalFrame.PIXELS ||
            fragment.size != 10 + pixelCount * 2 + 2) return null

        var a = current
        if (a == null || a.frameId != frameId) {
            a = Assembly(frameId, fragmentCount)
            current = a
        }
        if (a.count != fragmentCount) {
            current = null
            return null
        }
        var offset = 10
        for (i in 0 until pixelCount) {
            val raw = (u8(offset) or (u8(offset + 1) shl 8)).toShort().toInt()
            val value = raw / 100f
            if (!value.isFinite() || value !in -50f..500f) {
                current = null
                return null
            }
            a.values[pixelStart + i] = value
            a.received[pixelStart + i] = true
            offset += 2
        }
        if (a.received.all { it }) {
            val result = ThermalFrame(frameId.toLong(), timestampMs, a.values.copyOf())
            current = null
            return result
        }
        return null
    }

    private fun crc16(data: ByteArray, offset: Int, length: Int): Int {
        var crc = 0xffff
        for (i in offset until offset + length) {
            crc = crc xor ((data[i].toInt() and 255) shl 8)
            repeat(8) {
                crc = if ((crc and 0x8000) != 0) ((crc shl 1) xor 0x1021) and 0xffff
                else (crc shl 1) and 0xffff
            }
        }
        return crc
    }
}
