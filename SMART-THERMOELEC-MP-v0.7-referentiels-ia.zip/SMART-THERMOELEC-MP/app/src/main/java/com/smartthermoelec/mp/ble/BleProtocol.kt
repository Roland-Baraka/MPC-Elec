package com.smartthermoelec.mp.ble

import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.UUID

data class SensorPacket(
    val sequence: Long,
    val timestampMs: Long,
    val maxTempC: Float,
    val meanTempC: Float,
    val minTempC: Float,
    val accelRmsMg: Int,
    val accelPeakMg: Int,
    val flags: Int
)

object BleProtocol {
    val SERVICE_UUID: UUID = UUID.fromString("6d4f0001-8a3b-4c7d-9e11-001122334455")
    val CHARACTERISTIC_UUID: UUID = UUID.fromString("6d4f0002-8a3b-4c7d-9e11-001122334455")
    val CCCD_UUID: UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
    const val PACKET_SIZE = 27

    /** Paquet little-endian v1; CRC-16/CCITT-FALSE sur les 25 premiers octets. */
    fun decode(bytes: ByteArray): SensorPacket? {
        if (bytes.size != PACKET_SIZE) return null
        val expected = crc16(bytes, 0, 25)
        val b = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        val version = b.get().toInt() and 0xff
        if (version != 1) return null
        val seq = b.int.toLong() and 0xffffffffL
        val timestamp = b.long
        val max = b.short.toInt() / 100f
        val mean = b.short.toInt() / 100f
        val min = b.short.toInt() / 100f
        val rms = b.short.toInt() and 0xffff
        val peak = b.short.toInt() and 0xffff
        val flags = b.short.toInt() and 0xffff
        val received = b.short.toInt() and 0xffff
        if (received != expected || !max.isFinite() || !mean.isFinite() || !min.isFinite()) return null
        if (min > mean || mean > max || max !in -50f..500f) return null
        return SensorPacket(seq, timestamp, max, mean, min, rms, peak, flags)
    }

    private fun crc16(data: ByteArray, offset: Int, length: Int): Int {
        var crc = 0xffff
        for (i in offset until offset + length) {
            crc = crc xor ((data[i].toInt() and 0xff) shl 8)
            repeat(8) { crc = if ((crc and 0x8000) != 0) ((crc shl 1) xor 0x1021) and 0xffff else (crc shl 1) and 0xffff }
        }
        return crc
    }
}
