package com.smartthermoelec.mp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.MaterialTheme.colorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SmartThermoApp() }
    }
}

private enum class Diagnostic(val label: String, val advice: String) {
    STOPPED("ÉQUIPEMENT À L'ARRÊT", "Mettez l'équipement en fonctionnement uniquement selon les procédures du site."),
    INSUFFICIENT("DONNÉES INSUFFISANTES", "Vérifiez les températures, les seuils et le niveau de confiance."),
    NORMAL("FONCTIONNEMENT NORMAL (SELON SAISIE)", "Continuez la surveillance et comparez avec les valeurs constructeur."),
    WATCH("VIGILANCE", "Surveillez l'évolution et vérifiez la ventilation, la charge et les connexions."),
    WARNING("AVERTISSEMENT", "Faites contrôler l'équipement par une personne qualifiée selon les procédures du site."),
    CRITICAL("CRITIQUE", "Éloignez-vous si nécessaire et appliquez immédiatement la procédure de sécurité du site.")
}

@Composable
private fun SmartThermoApp() {
    var equipment by remember { mutableStateOf("Moteur électrique") }
    var running by remember { mutableStateOf(true) }
    var temperature by remember { mutableStateOf("65") }
    var ambient by remember { mutableStateOf("25") }
    var watch by remember { mutableStateOf("70") }
    var danger by remember { mutableStateOf("90") }
    var confidence by remember { mutableStateOf("80") }
    var result by remember { mutableStateOf(Diagnostic.INSUFFICIENT) }
    var evaluated by remember { mutableStateOf(false) }

    MaterialTheme {
        Surface(modifier = Modifier.fillMaxSize(), color = colorScheme.background) {
            Column(
                modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("SMART-THERMOÉLEC MP", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text("Surveillance thermique — prototype v0.4", style = MaterialTheme.typography.bodyMedium)
                Card(colors = CardDefaults.cardColors(containerColor = colorScheme.primaryContainer)) {
                    Column(Modifier.padding(14.dp)) {
                        Text("MODE DE DÉMONSTRATION", fontWeight = FontWeight.Bold)
                        Text("Les valeurs ci-dessous sont saisies manuellement. Aucun capteur n'est connecté dans cette version.")
                    }
                }
                Text("Équipement", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                OutlinedTextField(equipment, { equipment = it }, label = { Text("Type / nom de l'équipement") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { running = true; evaluated = false }, modifier = Modifier.weight(1f)) { Text("En marche") }
                    Button(onClick = { running = false; evaluated = false }, modifier = Modifier.weight(1f)) { Text("À l'arrêt") }
                }
                Text("Mesures saisies", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                NumberField("Température maximale (°C)", temperature) { temperature = it; evaluated = false }
                NumberField("Température ambiante (°C)", ambient) { ambient = it; evaluated = false }
                NumberField("Seuil de vigilance (°C)", watch) { watch = it; evaluated = false }
                NumberField("Seuil critique (°C)", danger) { danger = it; evaluated = false }
                NumberField("Confiance estimée (%)", confidence) { confidence = it; evaluated = false }
                Button(onClick = {
                    val t = temperature.toDoubleOrNull()
                    val a = ambient.toDoubleOrNull()
                    val w = watch.toDoubleOrNull()
                    val d = danger.toDoubleOrNull()
                    val c = confidence.toDoubleOrNull()
                    result = when {
                        !running -> Diagnostic.STOPPED
                        t == null || a == null || w == null || d == null || c == null -> Diagnostic.INSUFFICIENT
                        t < -50 || t > 500 || a < -50 || a > 100 || w <= a || d <= w || c !in 0.0..100.0 -> Diagnostic.INSUFFICIENT
                        c < 50 -> Diagnostic.INSUFFICIENT
                        t >= d -> Diagnostic.CRITICAL
                        t >= w -> Diagnostic.WARNING
                        t >= w - (d - w) * 0.25 -> Diagnostic.WATCH
                        else -> Diagnostic.NORMAL
                    }
                    evaluated = true
                }, modifier = Modifier.fillMaxWidth()) { Text("ÉVALUER L'ÉQUIPEMENT") }

                if (evaluated) {
                    Card(colors = CardDefaults.cardColors(containerColor = when(result) {
                        Diagnostic.CRITICAL, Diagnostic.WARNING -> colorScheme.errorContainer
                        Diagnostic.WATCH -> colorScheme.tertiaryContainer
                        else -> colorScheme.secondaryContainer
                    })) {
                        Column(Modifier.padding(16.dp)) {
                            Text(result.label, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                            Spacer(Modifier.height(6.dp))
                            Text(result.advice)
                            Divider(Modifier.padding(vertical = 8.dp))
                            Text("Équipement : $equipment")
                            Text("Température saisie : ${temperature} °C")
                            Text("Confiance saisie : ${confidence} %")
                        }
                    }
                }
                Text("Sécurité", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("Cet outil est une aide expérimentale. Il ne remplace ni les relais thermiques, ni les protections électriques, ni les procédures HSE. Ne prenez aucune décision d'exploitation sur la seule base de ce résultat.")
                Text("Développé comme prototype — BARAKA MUPIMBI Roland", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun NumberField(label: String, value: String, onValueChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = { text -> if (text.length <= 8 && text.all { it.isDigit() || it == '.' || it == '-' }) onValueChange(text) },
        label = { Text(label) },
        modifier = Modifier.fillMaxWidth(),
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
    )
}
