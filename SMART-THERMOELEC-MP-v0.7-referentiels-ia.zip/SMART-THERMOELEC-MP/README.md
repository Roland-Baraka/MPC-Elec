# SMART-THERMOÉLEC MP — v0.7 — référentiels thermiques, acoustiques et vibration

Package Android : `com.smartthermoelec.mp`  
Application Kotlin / Jetpack Compose, projet Gradle.

## Choix de conception
Le mode principal vise le coût minimal : capteurs du téléphone (accéléromètre et microphone).
L'accessoire ESP32 + MLX90640 est optionnel et réservé à une visualisation thermique de
surface, sur ligne de visée. Un téléphone standard ne mesure pas directement la température
interne d'un moteur ou d'un transformateur et ne voit pas à travers une carcasse opaque.

## Modules présents
- `phone/PhoneSensorMonitor.kt` : accéléromètre + niveau RMS micro.
- `thermal/ThermalFrame.kt` : modèle 32x24 et protocole de trames thermiques BLE fragmentées.
- `ble/` : client BLE et protocole capteurs précédemment préparés.
- `data/MeasurementStore.kt` : stockage SQLite.
- `ThermalAlerts.kt` : aide aux notifications Android.
- `firmware_esp32/` : firmware candidat capteurs; à adapter et valider sur le matériel exact.
- `docs/ARCHITECTURE_MODE_TELEPHONE.md` : limites physiques et architecture.
- `docs/METHODE_REFERENTIELS_IA.md` : méthode pour construire les trois plages, compenser l’ambiance et interpréter les courbes.
- `docs/PLAN_VALIDATION_TERRAIN.md` : protocole de validation.
- `docs/datasets/FORMAT_COLLECTE.csv` et `PROFILE_EQUIPEMENT_EXEMPLE.json` : format de collecte et gabarit de profil.

## État honnête
Les modules sont des briques de développement, pas un système complet déjà validé.
L'écran principal n'intègre pas encore tous les flux en temps réel; les permissions runtime
doivent être demandées par l'interface. Le protocole de trame thermique doit être implémenté
dans le firmware correspondant. Aucun modèle IA entraîné n’est inclus faute de données terrain validées. Le moteur v0.7 classe les données selon des seuils renseignés par profil ; les seuils sont volontairement vides/non universels et doivent être validés. Aucun essai matériel n’a été effectué dans cette archive.

Le mode téléphone seul ne doit pas afficher une température estimée comme une mesure réelle.
Les alertes doivent être présentées comme des signaux expérimentaux, pas comme des alarmes
de sécurité. Les protections électriques/thermiques et procédures HSE restent prioritaires.
