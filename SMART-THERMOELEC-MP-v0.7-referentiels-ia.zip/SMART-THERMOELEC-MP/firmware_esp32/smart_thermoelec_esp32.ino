/*
 * SMART-THERMOÉLEC MP — ESP32 sensor firmware integration candidate
 * Dependencies (Arduino Library Manager / Library Manager):
 * - Adafruit MLX90640
 * - Adafruit ADXL345
 * - Adafruit Unified Sensor
 * - NimBLE-Arduino (h2zero)
 *
 * I2C: MLX90640 address 0x33; ADXL345 usually 0x53 (ALT/SDO may select 0x1D).
 * Verify the actual board pinout and sensor voltage before wiring.
 * This firmware must be bench-tested and calibrated before any field use.
 */
#include <Wire.h>
#include <Adafruit_MLX90640.h>
#include <Adafruit_ADXL345_U.h>
#include <Adafruit_Sensor.h>
#include <NimBLEDevice.h>

static const char* DEVICE_NAME = "SMART-THERMOELEC-MP";
static const char* SERVICE_UUID = "6d4f0001-8a3b-4c7d-9e11-001122334455";
static const char* CHAR_UUID    = "6d4f0002-8a3b-4c7d-9e11-001122334455";

Adafruit_MLX90640 mlx;
Adafruit_ADXL345_Unified accel = Adafruit_ADXL345_Unified(12345);
NimBLECharacteristic* sensorCharacteristic = nullptr;
bool mlxReady = false, accelReady = false;
uint32_t sequenceNumber = 0;
float frame[32 * 24];

uint16_t crc16ccitt(const uint8_t* data, size_t len) {
  uint16_t crc = 0xFFFF;
  for (size_t i = 0; i < len; ++i) {
    crc ^= (uint16_t)data[i] << 8;
    for (uint8_t b = 0; b < 8; ++b)
      crc = (crc & 0x8000) ? (crc << 1) ^ 0x1021 : (crc << 1);
  }
  return crc;
}
void put16(uint8_t* p, int16_t v) { p[0] = (uint8_t)(v & 0xff); p[1] = (uint8_t)((v >> 8) & 0xff); }
void putU16(uint8_t* p, uint16_t v) { p[0] = (uint8_t)(v & 0xff); p[1] = (uint8_t)((v >> 8) & 0xff); }
void put32(uint8_t* p, uint32_t v) { for (int i=0;i<4;i++) p[i]=(v>>(8*i))&0xff; }
void put64(uint8_t* p, uint64_t v) { for (int i=0;i<8;i++) p[i]=(v>>(8*i))&0xff; }

bool readThermal(float& tMin, float& tMean, float& tMax) {
  if (!mlxReady || mlx.getFrame(frame) != 0) return false;
  tMin = 10000.0f; tMax = -10000.0f; double sum = 0; int count = 0;
  for (int i=0; i<768; ++i) {
    float t = frame[i];
    if (!isfinite(t) || t < -40 || t > 500) continue;
    tMin = min(tMin, t); tMax = max(tMax, t); sum += t; count++;
  }
  if (count < 600) return false;
  tMean = (float)(sum / count);
  return true;
}

// RMS d'accélération dynamique sur fenêtre : amplitude vectorielle après retrait
// d'une estimation de la composante moyenne (gravité + biais).
bool readVibration(uint16_t& rmsMg, uint16_t& peakMg) {
  if (!accelReady) return false;
  const int N = 32;
  float x[N], y[N], z[N], mx=0, my=0, mz=0;
  for (int i=0; i<N; ++i) {
    sensors_event_t event; accel.getEvent(&event);
    x[i]=event.acceleration.x; y[i]=event.acceleration.y; z[i]=event.acceleration.z;
    mx+=x[i]; my+=y[i]; mz+=z[i];
    delay(5);
  }
  mx/=N; my/=N; mz/=N;
  double sumSq=0; float peak=0;
  for (int i=0; i<N; ++i) {
    float dx=x[i]-mx, dy=y[i]-my, dz=z[i]-mz;
    float mag=sqrtf(dx*dx+dy*dy+dz*dz);
    sumSq += mag*mag; peak=max(peak,mag);
  }
  // 1 g = 1000 mg; cap to uint16 range.
  rmsMg=(uint16_t)constrain((int)(sqrt(sumSq/N)*1000.0f/9.80665f),0,65535);
  peakMg=(uint16_t)constrain((int)(peak*1000.0f/9.80665f),0,65535);
  return true;
}

void publishPacket() {
  float tMin, tMean, tMax;
  uint16_t vibRms=0, vibPeak=0;
  bool thermalOk=readThermal(tMin,tMean,tMax);
  bool vibrationOk=readVibration(vibRms,vibPeak);
  if (!thermalOk || !vibrationOk || sensorCharacteristic == nullptr) return;

  uint8_t p[27] = {0};
  p[0]=1; // protocol version
  put32(&p[1], sequenceNumber++);
  put64(&p[5], (uint64_t)millis());
  put16(&p[13], (int16_t)lroundf(tMax*100));
  put16(&p[15], (int16_t)lroundf(tMean*100));
  put16(&p[17], (int16_t)lroundf(tMin*100));
  putU16(&p[19], vibRms);
  putU16(&p[21], vibPeak);
  putU16(&p[23], 0); // flags: 0 = données capteurs valides; définir les bits documentés
  putU16(&p[25], crc16ccitt(p,25));
  sensorCharacteristic->setValue(p, sizeof(p));
  sensorCharacteristic->notify();
}

void setup() {
  Serial.begin(115200);
  Wire.begin(); // Définir explicitement SDA/SCL si la carte l'exige.
  mlxReady = mlx.begin(0x33, &Wire);
  if (mlxReady) mlx.setMode(MLX90640_CHESS);
  accelReady = accel.begin();
  if (accelReady) accel.setRange(ADXL345_RANGE_16_G);

  NimBLEDevice::init(DEVICE_NAME);
  NimBLEServer* server = NimBLEDevice::createServer();
  NimBLEService* service = server->createService(SERVICE_UUID);
  sensorCharacteristic = service->createCharacteristic(
    CHAR_UUID, NIMBLE_PROPERTY::READ | NIMBLE_PROPERTY::NOTIFY
  );
  service->start();
  NimBLEAdvertising* advertising = NimBLEDevice::getAdvertising();
  advertising->addServiceUUID(SERVICE_UUID);
  advertising->start();

  Serial.printf("MLX90640: %s | ADXL345: %s\n",
    mlxReady ? "OK" : "ERREUR", accelReady ? "OK" : "ERREUR");
}

void loop() {
  publishPacket();
  delay(1000);
}
